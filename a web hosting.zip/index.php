<?php
// MINATO HOST - Multi-file Web Hosting Platform
session_start();

// Admin Configuration
define('ADMIN_EMAIL', 'minatotechx@gmail.com');
define('ADMIN_PASSWORD', 'Whitexminato5151@');

$is_admin = isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;

// Handle Admin Authentication
if (isset($_POST['action']) && $_POST['action'] === 'login') {
    $email = trim($_POST['admin_email'] ?? '');
    $password = $_POST['admin_password'] ?? '';

    if ($email === ADMIN_EMAIL && $password === ADMIN_PASSWORD) {
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['success'] = "Access Granted. Welcome back, Commander.";
    } else {
        $_SESSION['error'] = "Invalid administrative credentials.";
    }
    header("Location: index.php");
    exit;
}

// Handle Admin Logout
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    unset($_SESSION['admin_logged_in']);
    $_SESSION['success'] = "Administrative session terminated.";
    header("Location: index.php");
    exit;
}

// Handle Admin Delete Project Request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete_site') {
    if (!$is_admin) {
        $_SESSION['error'] = "Unauthorized access attempt.";
        header("Location: index.php");
        exit;
    }

    $target = trim($_POST['target_filename'] ?? '');

    if (empty($target) || strpos($target, '..') !== false || strpos($target, '/') !== false || strpos($target, '\\') !== false) {
        $_SESSION['error'] = "Invalid deployment signature.";
    } else {
        $path = 'sites/' . $target;
        if (file_exists($path)) {
            if (is_dir($path)) {
                deleteDirectory($path);
                $_SESSION['success'] = "Project directory '$target' completely purged.";
            } else {
                unlink($path);
                $_SESSION['success'] = "Project file '$target' permanently deleted.";
            }
        } else {
            $_SESSION['error'] = "Target deployment does not exist.";
        }
    }
    header("Location: index.php");
    exit;
}

// Handle GitHub-Style Multi-file Project Creation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'create_project') {
    $project_name = cleanCustomUrl($_POST['project_name'] ?? '');
    $filenames = $_POST['filename'] ?? [];
    $contents = $_POST['file_content'] ?? [];

    if (empty($project_name)) {
        $_SESSION['error'] = "Please provide a valid project name.";
        header("Location: index.php");
        exit;
    }

    $project_dir = 'sites/' . $project_name;

    if (file_exists($project_dir)) {
        $_SESSION['error'] = "The repository name '$project_name' is already taken.";
        header("Location: index.php");
        exit;
    }

    // Validate filenames and extensions (Only HTML and CSS allowed)
    $has_index = false;
    $valid_files = [];

    foreach ($filenames as $index => $filename) {
        $filename = trim($filename);
        if (empty($filename)) continue;

        // Force lowercase and remove dangerous characters
        $filename = preg_replace('/[^a-zA-Z0-9._-]/', '', $filename);
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

        if (!in_array($ext, ['html', 'css'])) {
            $_SESSION['error'] = "Security Violation: Only .html and .css files are allowed! Rejected: $filename";
            header("Location: index.php");
            exit;
        }

        if ($filename === 'index.html') {
            $has_index = true;
        }

        $valid_files[] = [
            'name' => $filename,
            'content' => $contents[$index] ?? ''
        ];
    }

    if (!$has_index) {
        $_SESSION['error'] = "Repository rules requirement: You must include an 'index.html' file to serve as the homepage.";
        header("Location: index.php");
        exit;
    }

    // Initialize environment directory if missing
    if (!is_dir('sites')) {
        mkdir('sites', 0777, true);
    }

    // Create custom repository workspace
    mkdir($project_dir, 0777, true);

    // Save files into workspace
    foreach ($valid_files as $file) {
        file_put_contents($project_dir . '/' . $file['name'], $file['content']);
    }

    $_SESSION['success'] = "Repository '$project_name' compiled and deployed successfully!";
    $_SESSION['file_url'] = getWebsiteUrl($project_name);
    header("Location: index.php");
    exit;
}

// Recursive directory cleaner
function deleteDirectory($dir) {
    if (!file_exists($dir)) return true;
    if (!is_dir($dir)) return unlink($dir);
    foreach (scandir($dir) as $item) {
        if ($item == '.' || $item == '..') continue;
        if (!deleteDirectory($dir . DIRECTORY_SEPARATOR . $item)) return false;
    }
    return rmdir($dir);
}

function cleanCustomUrl($url) {
    $url = preg_replace('/[^a-z0-9-]/', '', strtolower($url));
    $url = preg_replace('/-+/', '-', $url);
    return trim($url, '-');
}

function getWebsiteUrl($path) {
    $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'];
    $base_url = $protocol . '://' . $host . dirname($_SERVER['PHP_SELF']);
    return rtrim($base_url, '/') . '/view.php?site=' . $path;
}

// Fetch compiled project structures
$deployed_projects = [];
if (is_dir('sites')) {
    foreach (scandir('sites') as $folder) {
        if ($folder !== '.' && $folder !== '..') {
            $path = 'sites/' . $folder;
            if (is_dir($path)) {
                // Count files inside workspace
                $all_files = array_diff(scandir($path), ['.', '..']);
                $file_count = count($all_files);
                
                $total_size = 0;
                foreach ($all_files as $f) {
                    $total_size += filesize($path . '/' . $f);
                }

                $deployed_projects[] = [
                    'name' => $folder,
                    'url' => getWebsiteUrl($folder),
                    'files_count' => $file_count,
                    'size' => $total_size,
                    'time' => filemtime($path)
                ];
            }
        }
    }
    usort($deployed_projects, function($a, $b) { return $b['time'] - $a['time']; });
}

function formatSize($bytes) {
    if ($bytes == 0) return '0 B';
    $units = ['B', 'KB', 'MB'];
    $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
    return round($bytes / pow(1024, $pow), 2) . ' ' . $units[$pow];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MINATO HOST - Multi-Page Core</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif; }
        body { background-color: #0d1117; color: #c9d1d9; padding: 25px; }
        .container { max-width: 1200px; margin: 0 auto; }
        
        .header { background: #161b22; padding: 30px; border-radius: 12px; border: 1px solid #30363d; margin-bottom: 25px; position: relative; text-align: center; }
        .header h1 { color: #58a6ff; font-size: 2.2rem; font-weight: 600; letter-spacing: 1px; display: flex; align-items: center; justify-content: center; gap: 12px; }
        .header p { color: #8b949e; margin-top: 8px; font-size: 0.95rem; }
        
        .admin-badge { position: absolute; top: 15px; right: 15px; background: #f85149; color: white; padding: 4px 12px; border-radius: 20px; font-size: 0.75rem; font-weight: bold; }
        .admin-badge a { color: white; text-decoration: none; margin-left: 5px; text-decoration: underline; }

        .layout { display: grid; grid-template-columns: 7fr 5fr; gap: 25px; }
        @media (max-width: 900px) { .layout { grid-template-columns: 1fr; } }

        .panel { background: #161b22; border: 1px solid #30363d; border-radius: 12px; padding: 25px; margin-bottom: 25px; }
        .panel-title { font-size: 1.2rem; color: #f0f6fc; margin-bottom: 20px; display: flex; align-items: center; gap: 10px; border-bottom: 1px solid #21262d; padding-bottom: 10px; }

        .form-group { margin-bottom: 20px; }
        label { display: block; color: #c9d1d9; font-size: 0.85rem; font-weight: 600; margin-bottom: 6px; }
        input[type="text"], input[type="email"], input[type="password"], textarea { width: 100%; background: #0d1117; border: 1px solid #30363d; border-radius: 6px; padding: 10px; color: #c9d1d9; font-size: 0.9rem; }
        input:focus, textarea:focus { outline: none; border-color: #58a6ff; box-shadow: 0 0 0 3px rgba(88,166,255,0.15); }

        /* Git Repository File Stacks layout */
        .file-entry { background: #21262d; border: 1px solid #30363d; border-radius: 8px; padding: 15px; margin-bottom: 15px; position: relative; }
        .file-header-row { display: flex; gap: 10px; margin-bottom: 10px; }
        .code-textarea { font-family: "SFMono-Regular", Consolas, "Liberation Mono", Menlo, monospace; min-height: 160px; font-size: 0.85rem; resize: vertical; }

        .btn { display: inline-flex; align-items: center; justify-content: center; gap: 8px; padding: 10px 18px; font-size: 0.85rem; font-weight: 600; border-radius: 6px; cursor: pointer; border: 1px solid transparent; text-decoration: none; transition: 0.2s; }
        .btn-primary { background: #238636; color: white; border-color: rgba(240,246,252,0.1); }
        .btn-primary:hover { background: #2ea44f; }
        .btn-secondary { background: #21262d; color: #c9d1d9; border-color: #30363d; }
        .btn-secondary:hover { background: #30363d; border-color: #8b949e; }
        .btn-danger { background: #da3637; color: white; }
        .btn-danger:hover { background: #f85149; }
        
        .remove-file-btn { background: none; border: none; color: #f85149; cursor: pointer; font-size: 0.9rem; display: flex; align-items: center; gap: 4px; margin-left: auto; }
        .remove-file-btn:hover { text-decoration: underline; }

        .project-item { display: flex; align-items: center; justify-content: space-between; padding: 15px; border: 1px solid #30363d; background: #0d1117; border-radius: 8px; margin-bottom: 12px; }
        .project-meta { font-size: 0.75rem; color: #8b949e; margin-top: 4px; display: flex; gap: 12px; }
        .project-name-link { color: #58a6ff; font-weight: 600; text-decoration: none; font-size: 0.95rem; }
        .project-name-link:hover { text-decoration: underline; }

        .msg { padding: 15px; border-radius: 8px; margin-bottom: 20px; font-size: 0.9rem; line-height: 1.4; }
        .msg-success { background: rgba(46,164,79,0.15); border: 1px solid #2ea44f; color: #56d364; }
        .msg-error { background: rgba(248,81,73,0.15); border: 1px solid #f85149; color: #ff7b72; }

        .repo-badge { background: #30363d; color: #c9d1d9; font-size: 0.7rem; padding: 2px 6px; border-radius: 10px; border: 1px solid #444c56; font-weight: bold; }
        .rules-callout { background: rgba(56,139,253,0.1); border: 1px solid #388bfd; border-radius: 6px; padding: 12px; margin-bottom: 15px; font-size: 0.8rem; color: #79c0ff; }

        .toast { position: fixed; bottom: 20px; right: 20px; background: #58a6ff; color: #0d1117; font-weight: bold; padding: 12px 24px; border-radius: 6px; display: none; z-index: 9999; }
        footer { text-align: center; color: #8b949e; margin-top: 40px; font-size: 0.85rem; border-top: 1px solid #21262d; padding-top: 20px; }
    </style>
</head>
<body>

    <div class="toast" id="toast">Copied to Clipboard!</div>

    <div class="container">
        <div class="header">
            <?php if ($is_admin): ?>
                <div class="admin-badge"><i class="fas fa-shield-alt"></i> ROOT ADMIN | <a href="index.php?action=logout">LOGOUT</a></div>
            <?php endif; ?>
            <h1><i class="fab fa-git-alt"></i> MINATO HOST</h1>
            <p>Deploy multi-page interactive websites directly inside structured virtual repositories.</p>
        </div>

        <?php if (isset($_SESSION['success'])): ?>
            <div class="msg msg-success">
                <strong>Deployment Successful!</strong><br><?php echo $_SESSION['success']; ?>
                <?php if (isset($_SESSION['file_url'])): ?>
                    <div style="margin-top: 12px; display: flex; gap: 10px;">
                        <a href="<?php echo $_SESSION['file_url']; ?>" target="_blank" class="btn btn-primary" style="padding: 6px 12px;"><i class="fas fa-external-link-alt"></i> Open Project</a>
                        <button onclick="copyRaw('<?php echo $_SESSION['file_url']; ?>')" class="btn btn-secondary" style="padding: 6px 12px;"><i class="fas fa-copy"></i> Copy Link</button>
                    </div>
                <?php endif; ?>
                <?php unset($_SESSION['success'], $_SESSION['file_url']); ?>
            </div>
        <?php endif; ?>

        <?php if (isset($_SESSION['error'])): ?>
            <div class="msg msg-error">
                <strong>Operation Failure:</strong> <?php echo $_SESSION['error']; ?>
                <?php unset($_SESSION['error']); ?>
            </div>
        <?php endif; ?>

        <div class="layout">
            <div>
                <div class="panel">
                    <div class="panel-title"><i class="fas fa-folder-plus"></i> Initialize Multi-file Workspace</div>
                    
                    <div class="rules-callout">
                        <i class="fas fa-info-circle"></i> <strong>Repository Rules:</strong> Only <code>.html</code> and <code>.css</code> files are approved. Your workspace <strong>MUST</strong> contain an <code>index.html</code> entry to execute runtime launching.
                    </div>

                    <form method="POST" id="repo-form">
                        <input type="hidden" name="action" value="create_project">
                        
                        <div class="form-group">
                            <label>REPOSITORY/PROJECT NAME</label>
                            <input type="text" name="project_name" placeholder="portfolio-system-v2" required>
                        </div>

                        <div id="files-container">
                            <div class="file-entry" id="default-index-file">
                                <div class="file-header-row">
                                    <div style="width: 220px;">
                                        <input type="text" name="filename[]" value="index.html" readonly style="background: #161b22; cursor: not-allowed; font-weight: bold; color: #58a6ff;">
                                    </div>
                                    <span class="repo-badge" style="align-self: center;">HOMEPAGE REQUIRED</span>
                                </div>
                                <textarea name="file_content[]" class="code-textarea" placeholder="" required><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Minato Host Workspace</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>🚀 Multi-page Project Initialized</h1>
    <p>Welcome to your customized MINATO HOST repository architecture.</p>
    <a href="about.html">Learn More →</a>
</body>
</html></textarea>
                            </div>
                        </div>

                        <div style="display: flex; gap: 12px; margin-top: 20px;">
                            <button type="button" class="btn btn-secondary" onclick="addNewFileEntry()"><i class="fas fa-plus"></i> Add New File</button>
                            <button type="submit" class="btn btn-primary" style="margin-left: auto;"><i class="fas fa-cloud-upload-alt"></i> Deploy Workspace</button>
                        </div>
                    </form>
                </div>
            </div>

            <div>
                <div class="panel">
                    <div class="panel-title"><i class="fas fa-cubes"></i> Active Repositories</div>
                    
                    <div style="max-height: 450px; overflow-y: auto; padding-right: 4px;">
                        <?php if (!empty($deployed_projects)): ?>
                            <?php foreach ($deployed_projects as $project): ?>
                                <div class="project-item">
                                    <div>
                                        <a href="<?php echo $project['url']; ?>" target="_blank" class="project-name-link">
                                            <i class="fas fa-folder" style="color: #6272a4; margin-right: 4px;"></i> <?php echo htmlspecialchars($project['name']); ?>
                                        </a>
                                        <div class="project-meta">
                                            <span><i class="fas fa-file-code"></i> <?php echo $project['files_count']; ?> modules</span>
                                            <span><i class="fas fa-weight-hanging"></i> <?php echo formatSize($project['size']); ?></span>
                                        </div>
                                    </div>

                                    <div style="display: flex; gap: 6px;">
                                        <?php if ($is_admin): ?>
                                            <form method="POST" style="margin: 0;" onsubmit="return confirm('Confirm total workspace destruction of this project?');">
                                                <input type="hidden" name="action" value="delete_site">
                                                <input type="hidden" name="target_filename" value="<?php echo htmlspecialchars($project['name']); ?>">
                                                <button type="submit" class="btn btn-danger" style="padding: 6px 10px;" title="Purge Repository">
                                                    <i class="fas fa-trash-alt"></i>
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                        <button onclick="copyRaw('<?php echo addslashes($project['url']); ?>')" class="btn btn-secondary" style="padding: 6px 10px;">
                                            <i class="fas fa-copy"></i>
                                        </button>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div style="text-align: center; padding: 40px 0; color: #8b949e;">
                                <i class="fas fa-code-branch" style="font-size: 2.5rem; margin-bottom: 12px; opacity: 0.3;"></i>
                                <p>No multi-page project repositories detected on the network cluster.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <?php if (!$is_admin): ?>
                    <div class="panel">
                        <div class="panel-title"><i class="fas fa-terminal"></i> Administrative Access</div>
                        <form method="POST">
                            <input type="hidden" name="action" value="login">
                            <div class="form-group">
                                <label>ADMIN SIGNATURE</label>
                                <input type="email" name="admin_email" required placeholder="admin@node.com">
                            </div>
                            <div class="form-group">
                                <label>CRYPTOGRAPHIC PASS-KEY</label>
                                <input type="password" name="admin_password" required placeholder="••••••••">
                            </div>
                            <button type="submit" class="btn btn-danger" style="width: 100%;"><i class="fas fa-unlock-alt"></i> Authorize Protocol</button>
                        </form>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <footer>
            <p>DEV BY <strong>MINATO TECH</strong></p>
        </footer>
    </div>

    <script>
        // Inject new virtual file modules into workspace dynamically
        function addNewFileEntry() {
            const container = document.getElementById('files-container');
            const fileId = 'file_' + Date.now();
            
            const fileHtml = `
                <div class="file-entry" id="${fileId}">
                    <div class="file-header-row">
                        <div style="width: 250px;">
                            <input type="text" name="filename[]" placeholder="filename.css or about.html" required 
                                   onchange="validateFilenameExtension(this)">
                        </div>
                        <button type="button" class="remove-file-btn" onclick="document.getElementById('${fileId}').remove()">
                            <i class="fas fa-trash-alt"></i> Delete Module
                        </button>
                    </div>
                    <textarea name="file_content[]" class="code-textarea" placeholder="/* Insert your code code layout engine here */" required></textarea>
                </div>
            `;
            container.insertAdjacentHTML('beforeend', fileHtml);
        }

        // Strict client-side sandbox validation
        function validateFilenameExtension(input) {
            const val = input.value.trim().toLowerCase();
            const ext = val.split('.').pop();
            
            if (ext !== 'html' && ext !== 'css') {
                alert('Workspace Validation Error:\nOnly explicit .html and .css file formats can be processed inside this core!');
                input.value = '';
                input.focus();
            }
        }

        function copyRaw(text) {
            navigator.clipboard.writeText(text).then(() => {
                const toast = document.getElementById('toast');
                toast.style.display = 'block';
                setTimeout(() => { toast.style.display = 'none'; }, 2000);
            });
        }
    </script>
</body>
</html>